## はじめに

前回の記事では、SVNからGit/GitLabへの移行準備について記載しました。
今回はその続編として、**移行する際の具体的な手順と注意点**
**そして移行を担保する方法について解説します。**

## 2. Git/GitLab移行の実践手順とツール活用
本章では、SVNからGit/GitLabへの移行を実行に移すにあたり、`git-svn`コマンドの構文やオプション、
各種ケースへの対応方法、実務上の注意点について具体的に解説します。

### 2.0 環境要件
以下の環境を想定して本手順を記載します。
| 項目       | 前提条件                      |
|------------|-------------------------------|
| OS         | Windows 11                    |
| Git        | バージョン 2.50.0 以降        |
| git-svn    | Gitに付属のバージョン         |
| PowerShell | バージョン 5.1 以降           |

:::note:warn
本稿執筆時点（2025年6月）の Git 2.50.0 以降を想定した手順です。
今後のリリースで仕様が変わる可能性があるため、最新ドキュメントを参照してください。
:::

### 2.1. `git-svn` の基本構文と前提知識

git-svn は Git 本体に標準で付属するサブコマンドであり、SVNの履歴を Git に忠実に変換できる移行ツールです。
通常は Git を標準的なパッケージでインストールすることで利用可能です。
SVN のリビジョン履歴を Git のコミットとして再構築し、ブランチ・タグ情報も Git の形式で再現します。

#### 基本構文

SVN から Git に履歴を移行する際は、以下いずれかの手順で実行します：

- 2段階方式（推奨）：
柔軟な設定変更や段階的な履歴変換が可能です。

```
git svn init [SVN_URL] [オプション]
git svn fetch [オプション]
```

- 一括方式：
一度ですべての履歴を変換します。initとfetchを一度で実行します。

```
git svn clone [SVN_URL] [オプション] [出力先ディレクトリ]
```

主なオプション：

| オプション | 説明 | 使用可能なコマンド |
|------------|------|--------------------|
| `--stdlayout` | 標準構成（trunk/branches/tags）を自動認識して変換 | `init`, `clone`|
| `--trunk`, `--branches`, `--tags` | カスタムレイアウト向けに個別パス指定 | `init`, `clone` |
| `-authors-file=<file>`|SVNユーザー名をGit形式に変換するマッピングファイル|`init`,`clone`|
| `-r<start>:<end>` |特定のリビジョン範囲のみ変換|`init`,`clone`|
| `--ignore-paths='正規表現'`|除外するパスを正規表現で指定|`init`, `clone`（※fetchは設定ファイルの変更で対応可）|
| `--preserve-empty-dirs`|空ディレクトリを保持|`clone` のみ（fetchでは`.git/config`の設定が必要）|


:::note:warn
**双方向同期（Git⇔SVN）の利用に関する注意点**
`git-svn` は Git から SVN への **双方向同期**にも対応しており、`git svn dcommit` によって Git のコミットを SVN に反映できます。ただし、双方向運用は、「SVN を一時的に併用する移行期間」や「特定部門のみ先行してGitへ移行する段階的運用」など、明確な運用設計がある場合に限り使用することが推奨されます。
双方向同期の運用には、以下のようなリスクがあります：
1.Git のマージやリベースが SVN 側で正しく再現されない
2.コミット順や履歴整合性に関する制約
3.開発者の混乱や運用負荷の増大
:::

### 2.2. 標準レイアウトでの移行手順
SVN リポジトリが trunk/、branches/、tags/ の構成に従っている場合は、git-svn の --stdlayout オプションを使用することで
比較的容易に Git 形式へ変換できます。以下に、移行作業の基本的な流れを示します。

#### 2.2.1. Gitリポジトリを初期化
```bash
mkdir git-migration
cd git-migration
git svn init <SVN_URL> --stdlayout --authors-file=authors.txt

```
> SVN_URLはリポジトリのルートURLを指定します。(例:`svn+ssh://svn.example.com/project`)   
> authors.txtはSVNユーザ名をGitのAuthor形式に変換するマッピングファイルです。

#### 2.2.2. 履歴を変換
```bash
git svn fetch
```

- すべての履歴が順次変換され、ローカルのGitの履歴に反映されます。
- 時間がかかる場合があるため、初回は -r<start>:<end>で一部分だけ変換を行い動作確認することを推奨します。
- 特定のパスやバイナリファイルの除外方法は後述の「2.4 バイナリファイルの除外と管理方針」を参照ください。

:::note
**トラブルシュート**
authors.txtの記述ミスで「Unknown author」エラーが出た場合はauthors.txtを修正し、
fetchを再実行してください。途中で止まっても問題ありません。
:::

**改行コード（auto.crlf）の設定の事前確認**
Windows 環境で Git を利用する際、core.autocrlf の設定により 改行コード（LF/CRLF）が自動的に変換されることがあります。
特にLinux向けスクリプト（.shファイルなど）を扱う場合、改行がCRLFに変換されると、
Linux上でエラーになる等の不具合を引き起こす可能性があります。
Windows 版 Git ではインストール時にこの設定を指定できますが、
誤って設定を省略した場合は、以下の対応を検討してください。

- .gitattributes ファイルで明示的に LF を指定する
```
*.sh text eol=lf
```

- Windowsでも以下のように設定することで改行コードの自動変換を無効にできます。
```
git config --global core.autocrlf false
```


#### 2.2.3 パフォーマンス最適化
大規模リポジトリを移行する際は以下オプションを検討してください。
- `--revision` で履歴を範囲指定し段階的にGitへ変換
- `--no-metadata` でコミットメッセージ内の SVN 情報を除外し、軽量化
- `--log-window-size` でSVNから一度に取得する履歴数を調整し、効率化

> `--log-window-size`オプションの設定値は、
> ネットワーク環境やメモリ状況に応じてエラーにならない適宜値を調整が必要です。

##### `--log-window-size` の調整
- **ネットワーク負荷軽減**  
  ネットワーク帯域が狭い環境では、ラウンドトリップを減らすために大きめの値（例：1000～5000）を設定  
- **メモリ使用量抑制**  
  利用可能メモリが少ない環境では、一度に取得する件数を小さめの値（例：200～500）に設定  


#### 2.2.3. 内容の確認
```bash
git log --graph --all
git branch -a
```

:::note
**ブランチ名の標準化について**
git-svnではtrunkはデフォルトでmasterブランチに変換されます。
ただし、近年のGitリポジトリでは「main」ブランチ名が標準となっています。
**mainブランチが推奨される背景**
従来はmasterという名称が一般的でしたが、
この名称は英語圏において“対になる表現（例：slave）”を連想させるとの意見もあり、
近年では、**より中立的かつ包括的な名称である「main」を推奨する流れが広がっています。**
そのため、下記コマンドでmainへのリネームを推奨します。
`git branch -m master main`
:::

- SVN の trunk、ブランチ、タグが、Git 側では master、リモートブランチ、およびタグ相当の参照として変換・生成されていることを確認します。
  以下は、git-svn による標準レイアウトの変換結果を概念的に示した図です：

```mermaid
flowchart LR
  %% スタイル定義
  classDef svnStyle    fill:#e6f7ff,stroke:#3399cc,stroke-width:2px;
  classDef gitStyle    fill:#fff7e6,stroke:#cc9933,stroke-width:2px;
  classDef cmdStyle    fill:#1e1e1e,stroke:#555,stroke-width:1px,color:#ffffff,font-family:monospace,font-size:14px;
  classDef noteStyle   fill:transparent,stroke:#888,stroke-dasharray:4 2,color:#444,font-size:14px;

  %% 注釈ノード
  NOTE["「Gitタグとしては認識されないため、再定義が必要"]:::noteStyle

  %% SVN リポジトリ構成
  subgraph SVN [SVN リポジトリ構成]
    direction TB
    TR[trunk]
    BR[branches/feature-x]
    TG[tags/v1.0]
  end

  %% Git リポジトリ構成
  subgraph GIT [Git リポジトリ構成]
    direction TB
    M[master]
    B[remotes/feature-x]
    T[remotes/tags/v1.0]
  end

  %% フロー
  TR   -- fetch --> FETCH["git-svn fetch"]:::cmdStyle
  BR   -- fetch --> FETCH
  TG   -- fetch --> FETCH

  FETCH -- master  --> M
  FETCH -- feature --> B
  FETCH -- tags    --> T

  %% 注釈矢印
  NOTE -.-> T

  %% ノードスタイル適用
  class TR,BR,TG svnStyle
  class M,B,T gitStyle

```

> 上記図は、SVN の trunk・branches・tags が Git 上でどのような参照に変換されるかを示したものです。
> 特に tags は `remotes/tags/…` ブランチとして取り込まれ、Git タグとしては扱われない点に注意してください。


#### 2.2.4. リモートブランチにpush（必要に応じて）
```bash
git remote add origin https://gitlab.example.com/group/repo.git
git push -u origin main
```

### 2.3 Git タグとして再定義する手順と注意点
SVN の `/tags/` ディレクトリは、`git-svn` によって Git に変換される際、正式な Git タグではなく「リモートブランチのような参照」として取り込まれます。  
そのため、Git 上でタグとして適切に運用するには、以下のように手動で再定義する必要があります。

```
git tag v1.0 refs/remotes/tags/v1.0
git push origin v1.0  # 必要に応じてリモートに反映
```

:::note:warn
**なぜタグの再定義が必要なのか？**
git-svn は、SVN の /tags/ を Git のタグ（refs/tags/...）ではなく、refs/remotes/tags/... という リモートブランチのような参照として取り込みます。
SVN における「タグ」は、そのブランチと同様に変更可能なディレクトリのコピーであり、Git のような不変性や特別な意味を持ちません。
一方、Git のタグは「不変のバージョン識別子」として、GitHub/GitLabのUI表示やCI/CDトリガー、パッケージ管理などで特別な意味を持ちます。
この違いにより、SVN のタグは Git 上ではブランチとして扱われるため、正式な Git タグとして利用するには、git tag コマンドによる手動定義が必要です。
:::

### 2.4. カスタムレイアウトでの移行手順
標準的な trunk/, branches/, tags/レイアウトに沿わないSubversion リポジトリに対しては、git svn init の際に --trunk や --branches、--tags オプションを明示的に指定する必要があります。ここでは、よくあるカスタム構成パターンを例に、具体的な移行手順を解説します。

#### 2.4.1 構成パターンの代表例

- ケース1:trunkがサブディレクトリにある
```
/svn-root/
  ├── project-x/
  │     └── trunk/
  │     └── branches/
  │     └── tags/
```

この場合、以下のように --trunk などを明示的に指定します。

```
git svn init svn+ssh://svn.example.com/project \
  --trunk=trunk \
  --branches=branches \
  --tags=tags \
  --authors-file=authors.txt
```

- ケース2:branchesが複数階層に分かれている

```
/svn-root/
  └── trunk/
  └── branches/
        ├── dev/feature-a/
        ├── dev/feature-b/
        └── hotfix/issue-123/
```

このような階層的なブランチ構成（例：branches/dev/feature-a や branches/hotfix/issue-001 など）が存在する場合は、
--branches オプションで 各ブランチの親ディレクトリを明示的に複数指定する必要があります。
ワイルドカードによる branches/*/* のような再帰的指定は git-svn ではサポートされていません。
```
git svn init svn+ssh://svn.example.com/project \
  --trunk=trunk \
  --branches=branches/dev,branches/hotfix \
  --tags=tags \
  --authors-file=authors.txt
```
> --branches には複数のパターンをカンマ区切りで指定することも可能です（例：--branches=branches/dev/*,branches/hotfix/*）。

#### 2.4.2 事前検証の進め方と注意点
本番の履歴変換に入る前に、限定的な条件で動作検証を行うことで、
意図した通りにブランチやタグが正しく取り込まれるかを確認できます。以下のステップでの検証を推奨します。

1. -r<start>:<end>オプションでのリビジョン限定フェッチ
特定のリビジョンだけを対象にすることで、処理時間を抑えて構成の確認が必要です。
ただし、そのリビジョン範囲に対象ブランチ・タグへのコミットが存在しない場合、
Git 上にその参照（例：refs/remotes/feature-x）が生成されない点に注意が必要です。

```
# リビジョン1~10までの履歴を変換する
git svn fetch -r1:10
```

### 2.5. バイナリファイルの除外と管理方針

バイナリファイルは、Git による通常のバージョン管理には適しておらず、以下のような課題を引き起こす可能性があります。
- リポジトリサイズの肥大化
- 差分の取得・マージの困難さ
- クローンやCI/CD実行時の処理負荷の増加

そのため、バイナリファイルは原則として Git での直接管理を避け、成果物専用リポジトリや GitHub/GitLab のアーティファクト管理機能等へ移管することを推奨します。
これらのファイルは `.gitignore` によって除外することが基本方針となり、移行後の誤コミット防止にもつながります。
そうすることで、開発環境やCI/CDパイプラインの効率性や保守性を維持することができます。

#### 除外対象の例
- ビルド済みバイナリ（例：`.exe`, `.jar`, `.dll`）
- 一時的に生成されるアーカイブファイル（例：`.zip`, `.tar.gz`）
- 開発ツールやIDEによるキャッシュ・中間生成物（例：`.class`, `.log`, `.tmp`）
- 静的アセット（画像・音声・動画など）のうち、頻繁に変更されるもの
  - ※必要に応じて、Git LFS（Large File Storage）による管理を検討してください。
      後述のGit LFS を利用することで、バイナリファイルを Git リポジトリに含めつつ、サイズ管理・転送効率を最適化することが可能です。

#### 2.5.2 --ignore-paths オプションによる除外

git svn init/clone において --ignore-paths オプションを指定することで、
除外すべきディレクトリ・ファイルを正規表現でフィルタすることが可能です。

`git svn init` または `git svn clone` の実行時に `--ignore-paths` オプションを指定することで、特定のファイルやディレクトリを正規表現で除外することが可能です。


```
git svn init [SVN_URL] --ignore-paths="\.exe$|\.jar$"
```
> 上記の例では、.exe や .jar に該当するパスが git-svn によって無視され、それらのファイルは Git リポジトリに取り込まれません。
> fetch時に特定のパスを除外したい場合は`.git/config`に~の設定をすることで可能です。


**fetch 時にも適用するには？**
git svn fetch 単体では --ignore-paths を直接指定できないため、事前に .git/config に該当設定を追記することで除外を反映させる必要があります。
以下は設定例です：

```
[svn-remote "svn"]
  url = svn+ssh://svn.example.com/project
  fetch = trunk:refs/remotes/trunk
  ignore-paths = \.exe$|\.jar$
```


### 2.5.3 Git LFS の活用（大容量バイナリの必要時）

バイナリファイルを Git リポジトリ上で管理せざるを得ないケースでは、
履歴の肥大化やパフォーマンス低下を回避するために、Git LFSの導入を強く推奨します。
Git LFS を使用すると、大容量ファイルの実体は外部ストレージに格納され、Git にはポインタのみが記録されるため、
Gitリポジトリの肥大化を抑止することができます。   
以下は設定例です。:
```
git lfs install
git lfs track "*.zip"
```

> 「バイナリファイルが履歴に含まれる前（初回fetch前）」にgit lfsのインストール及び`.gitattributes`およびLFS trackを設定していることを確認することで手戻りを防止できます。

### 2.6. 移行後の整合性・品質認チェック
Git への移行が完了した後、本格運用を開始する前に、以下の観点で事前確認を行うことが推奨されます。
これにより、履歴の欠落や差分、ビルド不能などの問題を未然に防ぐことができます。

#### 2.6.1 Git移行後のファイル整合性検証（ハッシュ突合チェック）
SVN 側のエクスポート結果と、Git に取り込んだ作業ツリーの内容が完全に一致しているかを確認することで、移行漏れや変換ミスの有無を検出できます。
以下の PowerShell スクリプトでは、2つのフォルダに含まれるファイルのハッシュを比較し、
差異があるファイルをリストアップします。svn export したディレクトリと、git checkout したディレクトリの差分比較を想定しています。

<details><summary>サンプルコード</summary>

```powershell powershell
param(
    [Parameter(Mandatory = $true)][string]$Folder1,
    [Parameter(Mandatory = $true)][string]$Folder2
)

function Get-FolderHashes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath
    )
    ls $RootPath -Recurse -File |
      ? { $_.FullName -notmatch '\\\.git(\\|$)' -and $_.FullName -notmatch '\\\.svn(\\|$)' } |
      % {
          $relative = [System.IO.Path]::GetRelativePath($RootPath, $_.FullName)
          $hash     = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
          [PSCustomObject]@{
              FilePath = $relative
              Hash     = $hash
          }
      }
}

# 各フォルダのハッシュを突合して表示
$hashes1 = Get-FolderHashes -RootPath $Folder1
$hashes2 = Get-FolderHashes -RootPath $Folder2
$diffs = Compare-Object -ReferenceObject $hashes1 `
                       -DifferenceObject $hashes2 `
                       -Property FilePath,Hash

if ($diffs) {
    $diffs |
      Select-Object `
        @{Name='Status';Expression={ `
        if ($_.SideIndicator -eq '<=') { "Only in $(Split-Path $Folder1 -Leaf)" } `
        else { "Only in $(Split-Path $Folder2 -Leaf)" } }}, FilePath,Hash | Format-Table -AutoSize
}
else {
    Write-Host "両フォルダの内容は完全に一致しています。" -ForegroundColor Green
}
```
</details>

#### 2.6.2 改行コードの検証
Windows上で動作するスクリプトや設定ファイルがCRLFになっていること、
Linux上で動作するスクリプトや設定ファイルの改行コードがLFになっていることを確認します。

#### 2.6.3 ビルドチェック
ビルドスクリプトが動作するかの確認や、ビルド・テスト・静的解析が成功することを確認します。

## 3. まとめ
本記事では、SVNからGit/GitLabへの移行による改善効果の整理から、検討ポイント、
具体的な移行手順、注意すべき技術的・運用的な事項までを解説しました。

Gitへの移行は単なるツール変更ではなく、**開発プロセスの見直しや効率化を進める機会**でもあります。
本記事が、Git/GitLabへのスムーズな移行と、より良い開発プロセスの構築に向けた一助となれば幸いです。
