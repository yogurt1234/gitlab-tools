// build.js
(async () => {
  const fs = require('fs');
  const path = require('path');
  const MarkdownIt = require('markdown-it');
  const container = require('markdown-it-container');
  const hljs = require('highlight.js');
  const attrs = require('markdown-it-attrs');
  const readline = require('readline');
  const { execSync } = require('child_process');
  const { getLinkPreview } = require('link-preview-js');
  const { default: replaceAsync } = await import('string-replace-async');

  const mdFiles = fs.readdirSync(process.cwd())
    .filter(fname => fname.endsWith('.md'));
  if (mdFiles.length === 0) {
    console.error('❌ カレントディレクトリに .md ファイルが見つかりません');
    process.exit(1);
  }
  const css = fs.readFileSync('style.css', 'utf8');
  // 5. 各 Markdown を HTML に変換＆出力
  for (const inputMd of mdFiles) {

    const outputHtml = inputMd.replace(/\.md$/, '.html');

    // 1. MarkdownIt 初期化
    const md = new MarkdownIt({
      html: true,
      breaks: false,
      highlight: (str, lang) => {
        if (lang && hljs.getLanguage(lang)) {
          try {
            return hljs.highlight(str, { language: lang }).value;
          } catch (_) { }
        }
        return md.utils.escapeHtml(str);
      }
    });

    // 2. フェンスルール拡張：Mermaid は事前に SVG → Base64 で <img> に埋め込む
    const prevFence = md.renderer.rules.fence || md.renderer.renderToken;
    md.renderer.rules.fence = (tokens, idx, options, env, self) => {
      const token = tokens[idx];
      const info = token.info.trim().split(/\s+/);
      const lang = info[0] || '';

      if (lang === 'mermaid') {
        // .mmd と .svg の一時ファイル
        const tmpMmd = path.join(__dirname, `.tmp-diagram-${idx}.mmd`);
        const tmpSvg = path.join(__dirname, `.tmp-diagram-${idx}.svg`);

        // 必要ならディレクトリを作成
        if (!fs.existsSync(path.dirname(tmpMmd))) {
          fs.mkdirSync(path.dirname(tmpMmd), { recursive: true });
        }
        // Mermaid ソースを書き出し
        fs.writeFileSync(tmpMmd, token.content, 'utf8');

        // Mermaid CLI で SVG に変換（npx mmdc）
        execSync(`npx mmdc -i "${tmpMmd}" -o "${tmpSvg}"`);

        // SVG を読み込み、Base64 にエンコード
        const svgContent = fs.readFileSync(tmpSvg, 'utf8');
        const base64 = Buffer.from(svgContent).toString('base64');

        try {
          fs.unlinkSync(tmpMmd);
          fs.unlinkSync(tmpSvg);
        } catch (err) {
          console.warn(`⚠️ 一時ファイルの削除に失敗しました: ${tmpMmd}, ${tmpSvg}`, err);
        }

        // <img> タグとして返却
        return ''
          + '<img class="mermaid" '
          + 'src="data:image/svg+xml;base64,' + base64 + '" '
          + 'alt="Mermaid diagram" />\n';
      }

      // その他のコードブロックはファイル名ラベル付きで出力
      const filenameMatch = token.info.match(/filename=(\S+)/);
      const filename = filenameMatch
        ? filenameMatch[1]
        : (info[1] || '');

      const code = options.highlight
        ? options.highlight(token.content, lang)
        : md.utils.escapeHtml(token.content);

      if (!token.content) {
        return prevFence(tokens, idx, options, env, self);
      }

      // ボタンとプリをまとめたコンテナで返す
      return `
      <div class="code-container">
        <button class="copy-btn" title="コードをコピー">🗐</button>
        <pre class="code-block" data-filename="${filename}"><code class="language-${lang} hljs">${code}</code></pre></div>`;
    };

    md.use(attrs);

    // 2.5. 画像ルール拡張：Markdownの画像をBase64化して埋め込む
    const defaultImage = md.renderer.rules.image || md.renderer.renderToken;
    md.renderer.rules.image = (tokens, idx, options, env, self) => {
      const token = tokens[idx];
      const src = token.attrGet('src');
      const alt = token.content || token.attrGet('alt') || '';
      const width = token.attrGet('width') || '';
      const height = token.attrGet('height') || '';

      let dataUri;
      try {
        // 環境変数 cwd または プロジェクトルートから画像読み込み
        const imgPath = path.resolve(env.cwd || process.cwd(), src);
        const buffer = fs.readFileSync(imgPath);
        const mime = 'image/' + path.extname(src).slice(1);
        dataUri = `data:${mime};base64,${buffer.toString('base64')}`;
      } catch (err) {
        console.warn(`⚠️ 画像埋め込み失敗: ${src}`, err);
        // フォールバックで元のパスを利用
        dataUri = src;
      }

      // <img>タグを組み立て
      let imgTag = `<img src="${dataUri}" alt="${alt}"`;
      if (width) imgTag += ` width="${width}"`;
      if (height) imgTag += ` height="${height}"`;
      imgTag += '>';
      return imgTag;
    };


    // 3. note コンテナ定義（info / warn / alert）
    ['', 'warn', 'alert'].forEach(type => {
      md.use(container, `note${type ? ':' + type : ''}`, {
        render(tokens, idx) {
          const t = tokens[idx];
          return t.nesting === 1
            ? `<div class="note${type ? ' note--' + type : ''}">`
            : `</div>`;
        }
      });
    });

    const linkPreviewCss = fs.readFileSync(
      path.resolve(__dirname, 'link-preview.css'),
      'utf8'
    );

    // 4. Markdown と CSS 読み込み
    const markdown = fs.readFileSync(inputMd, 'utf8');
    const css = fs.readFileSync('style.css', 'utf8');
    // インスタンス md の render メソッドを呼び出し、マークダウン文字列を HTML に変換
    let htmlContent = md.render(markdown);


    // ————— Markdown 中の「単独 URL」行をリンクカードに置換 —————
    htmlContent = await replaceAsync(
      htmlContent,
      // <p><a href="...">...</a></p> のみを対象に
      /<p><a href="(https?:\/\/[^"]+)">[^<]+<\/a><\/p>/g,
      async (_, url) => {
        try {
          //const data = await getLinkPreview(url);
          // OG／oEmbed 情報を取得しつつ、description は常に空にする
          const data = await getLinkPreview(url, { oEmbedProxy: null });
          data.description = '';

          const img = data.images && data.images[0] ? data.images[0] : '';
          return `
            <link-preview url="${url}">
              <template shadowrootmode="open">
                <style>
                  ${linkPreviewCss}
                </style>
                <a class="link-card" href="${url}" target="_blank" rel="noopener">
                  ${img ? `<img src="${img}" alt="${data.title}" />` : ''}
                  <div class="link-meta">
                    <h4>${data.title}</h4>
                    <small>${url}</small>
                  </div>
                </a>
              </template>
            </link-preview>`;
        } catch (e) {
          // 取得失敗時はそのまま元のリンクを戻す
          return `<p><a href="${url}">${url}</a></p>`;
        }
      }
    );

    // 5. HTML 全体組み立て & 出力
    const html = `<!DOCTYPE html>
      <html lang="ja">
      <head>
        <meta charset="UTF-8" />
        <title>${inputMd}</title>
      <style>
        ${css}
      </style>
      </head>
      <body>
        <article id="blog-root">
          <template shadowrootmode="open">
            <style>
              ${css}
            </style>
            ${htmlContent}
          </template>
      </article>
      <!-- 画像拡大モーダル -->
      <div class="image-modal" id="image-modal">
        <a class="download-btn" id="download-btn" download>ダウンロード</a>
        <img id="modal-img" src="" alt="拡大画像">
      </div>

  <script>
    // 1) クリップボードコピー関数（モダン＆フォールバック両対応）
    function copyToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.top = '-9999px';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      try {
        document.execCommand('copy');
        return Promise.resolve();
      } catch (e) {
        return Promise.reject(e);
      } finally {
        document.body.removeChild(ta);
      }
    }

    // 2) シャドウルート内外を問わずコピーアイコンを検出できるように
    const host = document.querySelector('#blog-root');
    const root = host.shadowRoot || document;
    root.addEventListener('click', e => {
      const btn = e.composedPath().find(el =>
        el instanceof Element && el.classList.contains('copy-btn')
      );
      if (!btn) return;
      const codeEl = btn.parentElement.querySelector('code');
      copyToClipboard(codeEl.innerText)
        .then(() => {
          btn.textContent = '✓ コピーしました';
          btn.classList.add('copied');
          setTimeout(() => {
            btn.classList.remove('copied');
            btn.innerHTML = '🗐';
          }, 2000);
        })
        .catch(() => {
          btn.textContent = 'コピー失敗';
          setTimeout(() => btn.innerHTML = '🗐', 2000);
        });
    });

    <!-- クリック→拡大・ダウンロード機能 -->
    window.addEventListener('DOMContentLoaded', () => {
      // 1) Shadow DOM があるかチェック、なければ document を使う
      const host = document.querySelector('#blog-root');
      const root = (host && host.shadowRoot) ? host.shadowRoot : document;
      const modal = document.getElementById('image-modal');
      const modalImg = document.getElementById('modal-img');
      const downloadBtn = document.getElementById('download-btn');

      // 2) 画像要素にバインド
      root.querySelectorAll('img').forEach(img => {
        img.classList.add('clickable-image');
        img.addEventListener('click', () => {
          modal.classList.add('is-visible');
          modalImg.src = img.src;
          downloadBtn.href = img.src;
        });
      });

     modal.addEventListener('click', e => {
       if (e.target === modal) {
         modal.classList.remove('is-visible');
       }
    });
    });
    </script>
  </body>
  </html>`;

    fs.writeFileSync(outputHtml, html, 'utf8');
    console.log('✅' + outputHtml + 'を生成しました');

  }
})().catch(err => {
  console.error('えらーだよー');
  console.error(err);
  process.exit(1);
});
