## はじめに

前回の記事では、SVN運用における課題やSVNからGit/GitLabへの移行によって期待される改善効果を整理しました。       
  
今回はその続編として、**SVNの履歴を保持したままGit/GitLabへ移行する際の検討事項、具体的な作業手順、git-svnの活用方法、**
**そして移行時に生じやすい問題とその回避策について解説します。**

移行にあたっては、SVNの履歴をGit形式に変換するためのツールとして`git-svn`が広く利用されています。
このツールを用いることでSVNリポジトリのコミット履歴をGitに取り込み、**移行後も過去の変更履歴をGitから参照することが可能です。**

## 1. 移行作業前の準備事項
Gitへの移行を実行する前に検討すべき事項を整理します。

### 1.1. SVNリポジトリレイアウトを確認する
移行元のリポジトリレイアウトを把握し、Gitリポジトリの最適な構成を検討します。

- **標準レイアウト(trunk／branches／tags)の場合は、`git-svn`の追加設定不要で移行可能です**(`--stdlayout`オプションを使用`)。
- カスタムレイアウトやモノリポジトリ（複数プロジェクトを1つのSVNリポジトリで管理している）の場合は、パスのマッピング等を決める必要があります。また、SVN上で一体となっていたコード群を単一のGitリポジトリで管理し続けるか、プロジェクトごとに複数のリポジトリへ分割するかを検討してください。

:::note
**履歴やブランチ/タグ欠落のリスク**
カスタムレイアウトを用いている場合、git-svnでのパス指定が誤っていると、意図したブランチやタグが正しく変換されず、履歴の欠落や構成の誤りが発生する恐れがあります。
:::

### 1.2. 移行対象の決定

リポジトリの規模と操作性のバランスを考慮し、移行対象とするブランチ、履歴、ファイルの範囲を明確に定めます。

- ブランチ／タグ
  - 更新頻度の低いブランチについては、アーカイブ用リポジトリへの移行、あるいは移行対象からの除外を検討してください。  
  - リリースタグは、将来のバグ対応や保守参照の用途に備え、最新の数件に限定して移行することを検討してください。
  
- ディレクトリ／ファイル
  - バイナリファイルはGitでの直接管理を避け、必要に応じてGit LFS（Large File Storage）の利用を検討してください。  
  - ExcelやWordなど、ファイルロック機能が求められるドキュメント類については、SVNや文書管理システムへの分離を推奨します。

- 変更履歴
  全変更履歴を移行すると、リポジトリサイズが肥大化し操作性の低下を招くおそれがあります。  
  - 移行対象を直近数年分の履歴に限定することを検討してください。  
  - 古い履歴については、別途アーカイブ用のGitリポジトリに保管する方針も有効です。

::: note:warn
**リポジトリの肥大化によるパフォーマンス低下懸念**  
**不要なデータをGitに取り込むと、リポジトリの肥大化やパフォーマンス低下の原因となります。**  
そのため、移行対象の適切な選別と、fetch前に一時ディレクトリなどで限定的に取得し、容量や履歴の整合性を事前検証することを推奨します。
:::

### 1.3. バイナリファイルの存在有無
大容量のバイナリファイルや、頻繁に更新・参照されるバイナリは、**Git本体で直接管理せず、Git LFSを利用して管理することを検討してください。**
Git LFSでは、リポジトリ本体にはファイルの実体ではなくポインタ情報のみを保持するため、リポジトリサイズの肥大化を防ぐことができます。

:::note
**なぜGitはバイナリファイルの管理が苦手か？**
Gitはファイルの履歴をスナップショットとして管理し、内部的には差分圧縮（デルタ圧縮）を用いて保存効率を高めています。
しかし、バイナリファイルは内容の差分が検出されにくく、圧縮が効きにくいため、更新のたびに大きな容量が追加で保存される傾向があります。
その結果、**頻繁に更新される大容量バイナリをGit本体で管理すると、リポジトリサイズが急速に肥大化し、クローンやフェッチに時間がかかるなど、操作性の低下を招きます。**  
このようなファイルは、Git LFSなどの外部ストレージ連携を用いて管理することが推奨されます。
:::

### 1.4. SVNの外部参照/内部参照の扱いの検討
SVNの `svn:externals` は、別リポジトリや別ディレクトリの内容を参照する仕組みです。  
ただし、`git-svn` によるデフォルト移行では、**参照元のプロパティ情報だけが取り込まれ、実体ファイル自体は移行されません。**
その結果、移行後に中身のないディレクトリが残るリスクがあります。

- **外部参照（他リポジトリを参照）**  
  - 移行後は、依存先を**別Gitリポジトリとして独立管理**、または**同一リポジトリへの統合**のいずれかを検討してください。
  - 参照元・依存先双方の更新フローやバージョン固定有無を事前に整理することが重要です。

- **内部参照（同一リポジトリ内の別ディレクトリを参照）**  
  - `svn:externals`を**移行前に解除し、実体ファイルを参照先から取得してコミット**することを推奨します。
  
:::note:warn
**よくある失敗例**
- `svn:externals`をそのまま移行し、依存ファイルが抜け落ちてビルドエラーやランタイムエラーが発生するケースが多く報告されています。  
- 特に「バージョンを明示的に固定しているexternals」の場合、移行後も過去の状態を再現する必要があるため、バージョン管理方針の明確化が必須です。
:::

### 1.5. SVNの空フォルダへの対応
Gitは空のフォルダを管理対象としません。そのため、移行後も空フォルダを保持する必要がある場合には、以下の方法を検討してください。

- `git-svn` の `--preserve-empty-dirs` オプションを使用すると、空ディレクトリにプレースホルダファイルが自動生成されます 
- プレースホルダの命名や管理方針を明確にしたい場合は、`.gitkeep` などを手動で追加・コミットする

Gitでは空のフォルダは管理対象外であるため、構成上も**実際にファイルが存在するディレクトリのみを管理対象とすることが一般的**です。  
成果物やログ出力先など、特定の用途で空フォルダの保持が求められる場合を除き、**必要になった時点で作成する運用**が推奨されます。

### 1.6. コミッター情報のマッピング（Author変換）
`git-svn` を使用してSVNの履歴をGitに移行する際には、すべてのコミットに「氏名（Author Name）」と「メールアドレス（Author Email）」を付与する必要があります。  
SVNではユーザー名のみで履歴が記録されるため、Gitの形式に合わせて**ユーザー名とGit形式のAuthor情報を対応付けるマッピングファイル（authors.txt）**を用意する必要があります。

以下は、SVNリポジトリのログからユニークなユーザー名を抽出し、`username = Name <email>` 形式の `authors.txt` を自動生成するPowerShellスクリプトの例です。

<details><summary>スクリプト例（generate_git_authors_from_svn.ps1）</summary>

```powershell
param(
    [Parameter(Mandatory=$true)][string]$svnUrl,
    [Parameter(Mandatory=$true)][string]$domain,
    [string]$output = "authors.txt"
)
svn log $svnUrl --quiet |
  Where-Object { $_ -match '^r\d+\s*\|\s*([^|]+)\s*\|' } |
  ForEach-Object {
    $user = $matches[1].Trim()
    "$user = $user <$user@$domain>"
  } |
  Sort-Object -Unique |
  Out-File $output -Encoding utf8NoBOM
```

> 上記スクリプトを使用する際は、SVN URLとメールアドレスのドメインを正確に指定する必要があります。
> また生成後は内容を必ず確認し、メールアドレスや氏名の修正を適切に行ってください。

</details>

:::note
**なぜコミッター情報のマッピングが必要か？**
Gitでは、すべてのコミットに「Author Name」と「Author Email」が必須です。
そのため、SVNのユーザ名をGit形式のAuthorにマッピングする --authors-file の事前設定が必要不可欠です。
マッピングが不完全な場合、`git-svn`実行時のエラーやコミッター情報の不整合等が起こる可能性があります。
:::

## 2. Git/GitLab移行の実践手順とツール活用
本章では、SVNからGit/GitLabへの移行を実行に移すにあたり、`git-svn`コマンドの構文やオプション、
各種ケースへの対応方法、実務上の注意点について具体的に解説します。

### 2.0 環境要件
以下の環境を想定して　本手順を記載しています。
| 項目       | 前提条件                      |
|------------|-------------------------------|
| OS         | Windows 11                    |
| Git        | バージョン 2.50.0 以降        |
| git-svn    | Gitに付属のバージョン         |
| PowerShell | バージョン 5.1 以降           |

### 2.1. `git-svn` の基本構文と前提知識
`git-svn`は Git 本体に含まれる公式サブコマンドのひとつであり、履歴付きでの移行が可能です。
通常は Git を標準的なパッケージでインストールすることで利用可能です。
SVNの各リビジョンをGitのコミットとして再構成し、ブランチやタグもGitの形式で再現します。

#### 基本構文

移行は通常、以下の2コマンドで構成されます：

```bash
git svn init [SVN_URL] [オプション]
git svn fetch
```

主なオプション：

| オプション | 説明 |
|------------|------|
| `--stdlayout` | 標準構成（trunk/branches/tags）を自動認識して変換 |
| `--trunk`, `--branches`, `--tags` | カスタムレイアウト向けに個別パス指定 |
| `--authors-file=xxx` | SVNのユーザー名をGit形式（名前・メール）に変換（省略時は `username <username@unknown>` となる） |
| `--preserve-empty-dirs` | SVNの空ディレクトリをGitにプレースホルダ付きで再現 |
| `-r<start>:<end>` | 指定したリビジョン範囲のみを取得（例：`-r1000:HEAD`）。履歴の一部だけを移行したい場合に有効 |
| `--ignore-paths='正規表現'` | 特定のファイル／ディレクトリを除外して取得。ログファイルやバイナリの除去などに有効 |
| `--dry-run` | 実際には実行せず、処理内容を検証できる。fetch や dcommit 前の安全確認に活用 |

:::note
initとfetchを一括実行するcloneコマンドも利用可能です。
しかし、柔軟な設定や構成変更を行いたい場合はinit + fetchの2ステップ実行が推奨されます。   
:::

:::note:warn
**双方向同期（Git⇔SVN）の利用に関する注意点**
`git-svn` は Git から SVN への **双方向同期**にも対応しており、`git svn dcommit` によって Git のコミットを SVN に反映できます。ただし、双方向運用は、「SVN を一時的に併用する移行期間」や「特定部門のみ先行してGitへ移行する段階的運用」など、明確な運用設計がある場合に限り使用することが推奨されます。
双方向同期の運用には、以下のようなリスクがあります：
1.Git のマージやリベースが SVN 側で正しく再現されない
2.コミット順や履歴整合性に関する制約
3.開発者の混乱や運用負荷の増大
:::

### 2.2. 標準レイアウトでの移行手順
SVN リポジトリが trunk/、branches/、tags/ の構成に従っている場合は、git-svn の --stdlayout オプションを使用することで比較的容易に Git 形式へ変換できます。
以下に、移行作業の基本的な流れを示します。

#### 2.2.1. Gitリポジトリを初期化
```bash
mkdir git-migration
cd git-migration
git svn init <SVN_URL> --stdlayout --authors-file=authors.txt
```
> SVN_URLはリポジトリのルートURLを指定します。(例:https://svn.example.com/repos/project)   
> authors.txtはSVNユーザ名をGitのAuthor形式に変換するマッピングファイルです。

#### 2.2.2. 履歴を取得
```bash
git svn fetch
```
- すべての履歴が順次取得され、Gitのローカル履歴に反映されます。
- 時間がかかる場合があるため、初回は -r<start>:<end>で1部だけ変換を行い動作確認を推奨します。
- 特定のパスやバイナリファイルの除外方法は後述の「2.4 バイナリファイルの除外と管理方針」を参照ください。

**改行コード（auto.crlf）の設定確認**
Windows環境で作業する場合、Gitの core.autocrlf 設定により改行コードが自動変換されることがあります。
とくにLinux向けスクリプト（.shファイルなど）を扱う場合、改行がCRLFに変換されると、
Linux側でエラーになる等の不具合を引き起こす可能性があります。以下の対策を検討してください。

- .gitattributes ファイルで明示的に LF を指定する
```
*.sh text eol=lf
```

- Windowsでも以下のように設定することで改行コードの自動変換を無効にできます。
```
git config --global core.autocrlf false
```

:::note
**トラブルシュート**
author.txtの記述ミスで「Unknown author」エラーが出た場合はauthor.txtを修正し、
fetchを再実行してください。途中で止まっても問題ありません。
:::

#### 2.2.3. 内容の確認
```bash
git log --graph --all
git branch -a
```

:::note
**ブランチ名の標準化について**
git-svnではtrunkはデフォルトでmasterブランチに変換されます。
ただし、近年のGitリポジトリでは「main」ブランチ名が標準となっています。
**なぜ「main」なのか？**
従来はmasterという名称が一般的でしたが、
この名称は英語圏において“対になる表現（例：slave）”を連想させるとの意見もあり、
近年では、**より中立的かつ包括的な名称である「main」を推奨する流れが広がっています。**
そのため、下記コマンドでmainへのリネームを推奨します。
`git branch -m master main`
:::

- SVN の trunk、ブランチ、タグが、Git 側では master、リモートブランチ、およびタグ相当の参照として変換・生成されていることを確認します。
  以下は、git-svn による標準レイアウトの変換結果を概念的に示した図です：

```mermaid
flowchart LR
  %% スタイル定義
  classDef svnStyle    fill:#e6f7ff,stroke:#3399cc,stroke-width:2px;
  classDef gitStyle    fill:#fff7e6,stroke:#cc9933,stroke-width:2px;
  classDef cmdStyle    fill:#1e1e1e,stroke:#555,stroke-width:1px,color:#ffffff,font-family:monospace,font-size:14px;
  classDef noteStyle   fill:transparent,stroke:#888,stroke-dasharray:4 2,color:#444,font-size:14px;

  %% 注釈ノード
  NOTE["このままではGitのTagとして扱われないため、再定義が必要"]:::noteStyle

  %% SVN リポジトリ構成
  subgraph SVN [SVN リポジトリ構成]
    direction TB
    TR[trunk]
    BR[branches/feature-x]
    TG[tags/v1.0]
  end

  %% Git リポジトリ構成
  subgraph GIT [Git リポジトリ構成]
    direction TB
    M[master]
    B[remotes/feature-x]
    T[remotes/tags/v1.0]
  end

  %% フロー
  TR   -- fetch --> FETCH["git-svn fetch"]:::cmdStyle
  BR   -- fetch --> FETCH
  TG   -- fetch --> FETCH

  FETCH -- master  --> M
  FETCH -- feature --> B
  FETCH -- tags    --> T

  %% 注釈矢印
  NOTE -.-> T

  %% ノードスタイル適用
  class TR,BR,TG svnStyle
  class M,B,T gitStyle

```

> 上記図は、SVN の trunk・branches・tags が Git 上でどのような参照に変換されるかを示したものです。
> 特に tags は `remotes/tags/…` ブランチとして取り込まれ、Git タグとしては扱われない点に注意してください。


#### 2.2.4. リモートブランチにpush（必要に応じて）
```bash
git remote add origin https://gitlab.example.com/group/repo.git
git push -u origin master
```

### 2.3 Git タグとして再定義する手順と注意点
SVN の `/tags/` ディレクトリは、`git-svn` によって Git に変換される際、正式な Git タグではなく「リモートブランチのような参照」として取り込まれます。  
そのため、Git 上でタグとして適切に運用するには、以下のように手動で再定義する必要があります。

```
git tag v1.0 refs/remotes/tags/v1.0
git push origin v1.0  # 必要に応じてリモートに反映
```

:::note:warn
**なぜ再定義が必要なのか？**
git-svn は、SVN の /tags/ を Git のタグ（refs/tags/...）ではなく、refs/remotes/tags/... という リモートブランチのような参照として取り込みます。
SVN における「タグ」は、そのブランチと同様に変更可能なディレクトリのコピーであり、Git のような不変性や特別な意味を持ちません。
一方、Git のタグは「不変のバージョン識別子」として、GitHub/GitLabのUI表示やCI/CDトリガー、パッケージ管理などで特別な意味を持ちます。
この違いにより、SVN のタグは Git 上ではブランチとして扱われるため、正式な Git タグとして利用するには、git tag コマンドによる手動定義が必要です。
:::

### 2.4. カスタムレイアウトでの移行手順
標準的な trunk/, branches/, tags/レイアウトに沿わないSubversion リポジトリに対しては、git svn init の際に --trunk や --branches、--tags オプションを明示的に指定する必要があります。ここでは、よくあるカスタム構成パターンを例に、具体的な移行手順を解説します。

#### 2.4.1 構成パターンの代表例

- ケース1:trunkがサブディレクトリにある
```
/svn-root/
  ├── project-x/
  │     └── trunk/
  │     └── branches/
  │     └── tags/
```

この場合、以下のように --trunk などを明示的に指定します。

```
git svn init https://svn.example.com/svn-root/project-x \
  --trunk=trunk \
  --branches=branches \
  --tags=tags \
  --authors-file=authors.txt
```

- ケース2:branchesが複数階層に分かれている

```
/svn-root/
  └── trunk/
  └── branches/
        ├── dev/feature-a/
        ├── dev/feature-b/
        └── hotfix/issue-123/
```

このような階層的なブランチ構成（例：branches/dev/feature-a や branches/hotfix/issue-001 など）が存在する場合は、
--branches オプションで 各ブランチの親ディレクトリを明示的に複数指定する必要があります。
ワイルドカードによる branches/*/* のような再帰的指定は git-svn ではサポートされていません。
```
git svn init https://svn.example.com/svn-root \
  --trunk=trunk \
  --branches=branches/dev,branches/hotfix \
  --tags=tags \
  --authors-file=authors.txt
```
> --branches には複数のパターンをカンマ区切りで指定することも可能です（例：--branches=branches/dev/*,branches/hotfix/*）。

#### 2.4.3 事前検証の進め方と注意点
本番の履歴取得に入る前に、限定的な条件で動作検証を行うことで、
意図した通りにブランチやタグが正しく取り込まれるかを確認できます。以下のステップでの検証を推奨します。

1. -r<start>:<end>オプションでのリビジョン限定フェッチ
特定のリビジョンだけを対象にすることで、処理時間を抑えて構成の確認が必要です。
ただし、そのリビジョン範囲に対象ブランチ・タグへのコミットが存在しない場合、
Git 上にその参照（例：refs/remotes/feature-x）が生成されない点に注意が必要です。

```
# リビジョン1~100までの履歴を変換する
git svn fetch -r1:100
```

1. --dry-runによる変換対象の事前確認
実際の変換を行わず、どのリビジョンや参照が取得対象になるかを事前に把握できます。
```
git svn fetch --dry-run
```

### 2.5. バイナリファイルの除外と管理方針

**以下のようなファイルは、履歴の肥大化やマージ不能といった問題を引き起こす**ため、原則として Git 管理の対象外とするのが望ましいです。
これらは .gitignore による除外、または移行時点での取得対象からの除外が基本方針となります。
また、.gitignoreに含めておくことで移行後のバイナリの誤コミットを防止できます。

- ビルド済みバイナリ（例：.exe, .jar, .dll）
- IDE やツールが出力するキャッシュファイルや中間生成物
- 静的アセット（画像・音声・動画など）のうち、頻繁に変更されるもの
- 一時的に生成される ZIP・アーカイブファイル

#### 2.5.2 --ignore-paths オプションによる除外

git svn init / fetch において --ignore-paths オプションを指定することで、
除外すべきディレクトリ・ファイルを正規表現でフィルタすることが可能です。
```
git svn fetch --ignore-paths="\.exe$|\.jar$"
```
> 上記の例では、.exe や .jar に該当するパスが git-svn によって無視され、それらのファイルは Git リポジトリに取り込まれません。

### 2.5.3 Git LFS の活用（大容量バイナリの必要時）

バイナリファイルを Git リポジトリ上で管理せざるを得ないケースでは、
履歴の肥大化やパフォーマンス低下を回避するために、Git LFSの導入を強く推奨します。
Git LFS を使用すると、大容量ファイルの実体は外部ストレージに格納され、Git にはポインタのみが記録されるため、
Gitリポジトリの肥大化を抑止することができます。
```
git lfs install
git lfs track "*.zip"
```

> 必ず「バイナリファイルが履歴に含まれる前（初回fetch前）」に`.gitattributes`およびLFS trackを設定していることを確認することで手戻りを防止できます。

### 2.6. 運用前チェック
Git への移行が完了した後、本格運用を開始する前に、以下の観点で事前確認を行うことが推奨されます。
これにより、履歴の欠落や差分、ビルド不能などの問題を未然に防ぐことができます。

#### 2.6.1 Git移行後のファイル整合性検証（ハッシュ突合チェック）
SVN 側のエクスポート結果と、Git に取り込んだ作業ツリーの内容が完全に一致しているかを確認することで、移行漏れや変換ミスの有無を検出できます。
以下の PowerShell スクリプトでは、2つのフォルダに含まれるファイルのハッシュを比較し、
差異があるファイルをリストアップします。svn export したディレクトリと、git checkout したディレクトリの差分比較を想定しています。

<details><summary>サンプルコード</summary>

```powershell powershell
param(
    [Parameter(Mandatory = $true)][string]$Folder1,
    [Parameter(Mandatory = $true)][string]$Folder2
)

function Get-FolderHashes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath
    )
    ls $RootPath -Recurse -File |
      ? { $_.FullName -notmatch '\\\.git(\\|$)' -and $_.FullName -notmatch '\\\.svn(\\|$)' } |
      % {
          $relative = [System.IO.Path]::GetRelativePath($RootPath, $_.FullName)
          $hash     = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
          [PSCustomObject]@{
              FilePath = $relative
              Hash     = $hash
          }
      }
}

# 各フォルダのハッシュを突合して表示
$hashes1 = Get-FolderHashes -RootPath $Folder1
$hashes2 = Get-FolderHashes -RootPath $Folder2
$diffs = Compare-Object -ReferenceObject $hashes1 `
                       -DifferenceObject $hashes2 `
                       -Property FilePath,Hash

if ($diffs) {
    $diffs |
      Select-Object `
        @{Name='Status';Expression={ `
        if ($_.SideIndicator -eq '<=') { "Only in $(Split-Path $Folder1 -Leaf)" } `
        else { "Only in $(Split-Path $Folder2 -Leaf)" } }}, FilePath,Hash | Format-Table -AutoSize
}
else {
    Write-Host "両フォルダの内容は完全に一致しています。" -ForegroundColor Green
}
```
</details>

#### 2.6.2 改行コードの検証
Windows上で動作するスクリプトや設定ファイルがCRLFになっていること、
Linux上で動作するスクリプトや設定ファイルの改行コードがLFになっていることを確認します。

#### 2.6.3 ローカルでのビルドチェック
ビルドスクリプトがローカルで動作するかの確認や、ビルド・テスト・静的解析が成功することを確認します。

## 3. まとめ
本記事では、SVNからGit/GitLabへの移行にあたっての検討ポイントから、
具体的な移行手順、注意すべき技術的・運用的な事項までを解説しました。

移行は単なるツール変更ではなく、**開発プロセスの見直しや効率化を進める機会**でもあります。
本記事が、Gitへのスムーズな移行と、より良い開発プロセスの構築に向けた一助となれば幸いです。
